"""
    Add system search paths for all the pPython files
    and define initial parameters necessary for pPython.
"""
import os
import sys

DEBUG = 0

# Set pPython HOME path environment
base_dir_path = os.path.dirname(os.path.abspath(__file__))
os.environ['PPYTHON_HOME'] = base_dir_path

# Set pPython runtime paths
sys.path.append(base_dir_path+os.sep+'src')
sys.path.append(base_dir_path+os.sep+'src'+os.sep+'map')
sys.path.append(base_dir_path+os.sep+'src'+os.sep+'dmat')
sys.path.append(base_dir_path+os.sep+'sched')
sys.path.append(base_dir_path+os.sep+'PythonMPI'+os.sep+'src')

# Share pPython Environment Variables
import pyMPI_COMM_WORLD as pyMCW

# Define MPI_COMM_WORLD dictionary if not defined.
try: comm
except NameError: comm = None
if comm is None:
        comm = pyMCW.MPI_COMM_WORLD
        if not isinstance(comm,dict):
            comm = dict()
            comm['rank'] = 0
try: Np
except NameError: Np = 1
try: Pid
except NameError: Pid = 0

# Check GPU availability
# Based on CUDA_VISIBLE_DEVICES
# use_gpu = (os.getenv('CUDA_VISIBLE_DEVICES','') != '')
CUDA_VISIBLE_DEVICES = os.getenv('CUDA_VISIBLE_DEVICES','')
# if (CUDA_VISIBLE_DEVICES == '0') or (CUDA_VISIBLE_DEVICES == ''):
if (CUDA_VISIBLE_DEVICES == ''):
    use_gpu = False
else:
    use_gpu = True

if DEBUG:
    print('pPython __init__: use_gpu = ',end='')
    print(use_gpu)
    print('pPython __init__: CUDA_VISIBLE_DEVICES = ',end='')
    print(os.getenv('CUDA_VISIBLE_DEVICES',''))
gpu_device = None
if use_gpu:
    import cupy as cp
    # The following code happens to work only because Pid is always 0 at this stage and, 
    # due to the GPU binding, only a single GPU is visible to the process.
    gpu_device = cp.cuda.Device(Pid%cp.cuda.runtime.getDeviceCount())
    # bug because only 1 GPU is visible to my process: gpu_device = cp.cuda.Device(int(CUDA_DEVICE_ID))

if DEBUG:
    print('pPython:')
    print('sys.path')
    print(sys.path)
    print('comm')
    print(comm)
    print('Np = %d, Pid = %d'%(Np,Pid))
    print(f"gpu_device: {gpu_device}")

########################################################
# pPython: Parallel Python Programming Tool
# Python extension: Dr. Chansup Byun (cbyun@ll.mit.edu)
# Software Engineer: Ms. Nadya Travinin (nt@ll.mit.edu)
# Architect:      Dr. Jeremy Kepner (kepner@ll.mit.edu)
# MIT Lincoln Laboratory
########################################################
# Copyright (c) 2023, Massachusetts Institute of Technology All rights 
# reserved.
# 
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are 
# met:
#      * Redistributions of source code must retain the above copyright 
#        notice, this list of conditions and the following disclaimer.
#      * Redistributions in binary form must reproduce the above copyright 
#        notice, this list of conditions and the following disclaimer in
#        the documentation and/or other materials provided with the
#        distribution.
#      * Neither the name of the Massachusetts Institute of Technology nor 
#        the names of its contributors may be used to endorse or promote 
#        products derived from this software without specific prior written 
#        permission.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
# IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
# THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
# PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

