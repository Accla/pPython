"""A setuptools based setup module.
See:
https://packaging.python.org/guides/distributing-packages-using-setuptools/
https://github.com/pypa/sampleproject
"""

# Always prefer setuptools over distutils
from setuptools import setup, find_packages
import pathlib

here = pathlib.Path(__file__).parent.resolve()

# Get the long description from the README file
long_description = (here / 'README.md').read_text(encoding='utf-8')

# Arguments marked as "Required" below must be included for upload to PyPI.
# Fields marked as "Optional" may be commented out.

# For installing pPython local configuration
PPYTHON_LOCAL_CONF = 'ppython_conf'

setup(
    name='pPython',  # Required
    version='0.9.7',  # Required
    description='A parallel Python tool project',  # Optional
    long_description_content_type='text/markdown',  # Optional (see note above)
    url='https://gitlab.llgrid.ll.mit.edu/llgrid/pPython',  # Optional
    author='Chansup Byun, Ph.D.',  # Optional
    author_email='cbyun@ll.mit.edu',  # Optional
    classifiers=[  # Optional
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',

        'Topic :: Software Development :: Build Tools',

        'License :: OSI Approved :: MIT License',

        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3 :: Only',

        'Operating System :: OS Independent',
    ],

    keywords='parallel computing, PGAS, MPI, development',  # Optional

    # package_dir={'': 'src'},  # Optional
    packages=find_packages(where='src'),  # Required

    #CB: distribute pPython local configuration files
    package_data = {
        '': ['*.txt', '*.xml', '*.special', '*.huh']
    },
    include_package_data = True,

    data_files=[
        (PPYTHON_LOCAL_CONF, ['src/pPython/ppython_conf/pyMPI_Comm_settings_local.py','src/pPython/ppython_conf/grid_config_local.py'])
    ],

    python_requires='>=3.8, <4',

    extras_require={  # Optional
         'examples': ['examples'],
    },

    # To provide executable scripts, use entry points in preference to the
    # "scripts" keyword. Entry points provide cross-platform support and allow
    # `pip` to create the appropriate form of executable for the target
    # platform.
    #
    # For example, the following would provide a command called `sample` which
    # executes the function `main` from this package when invoked:
    # entry_points={  # Optional
    #   'console_scripts': [
    #         'sample=sample:main',
    #    ],
    # },

)


