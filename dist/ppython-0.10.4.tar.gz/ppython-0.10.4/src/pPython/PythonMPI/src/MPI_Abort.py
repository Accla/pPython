import os
from glob import glob
import random
import string
import subprocess

from pyMPI_Comm_settings import *
import checkOS as OS

def MPI_Abort():
    """MPI_Abort  -  Aborts any currently running MatlabMPI sessions.

    Usage:
    ------
    MPI_Abort()

    Will abort any currently running PythonMPI sessions
    by looking for leftover PythonMPI jobs and killing them.
    Cannot be used after pyMPI_Delete_all. 
    
    Python version: Dr. Chansup Byun
    """

    # global isunix, ismac, islinux, ispc

    # return if PythonMPI directory does not exist
    if not os.path.exists('PythoMPI'):
        return
    
    # Get host name.
    if (OS.isunix):
        host = os.uname()[1]
    elif (OS.ispc):
        host = os.getenv('computername')

    # Get possibly user defined settings.
    machine_db_settings = pyMPI_Comm_settings()
    remote_launch = machine_db_settings['remote_launch']
    remote_flags = machine_db_settings['remote_flags']

    # Get list of pid files.
    pid_files = glob('PythonMPI/pid.*.*')
    n_files = len(pid_files)

    # Save the pid list for the same machine in a dictionary variable
    pid_list = dict()

    # Set some strings for special characters.
    # Get single quote character. 
    q = '\''
    qq = '"'

    # Get username (assuming local and remote username are the same)
    username = os.getlogin()
        
    # Check if there are any files
    if (n_files < 1):
        print('No pid files found')
    else:
        # Loop over each file.
        for i_file in range(n_files):
            # Python index starts from 0
            # Get file name.
            file_name = pid_files[i_file]
            # Check if there is a pid appended.
            tstr = file_name.split('.')
            if len(tstr) >=3:
                # Parse file name.
                machine = '.'.join(tstr[1:-1])
                pid = tstr[-1]
                if machine not in pid_list:
                    pid_list[machine] = []
                    pid_list[machine].append(pid)
                else:
                    pid_list[machine].append(pid)

        # Loop over each machine.
        for i_m in pid_list.keys():
            # List all the process pid on the same machine
            for i_m in pid_list.keys():
                pid = ' '.join(pid_list[i_m])
                machine = i_m

            # Check if the target machine is a PC
            if pid == 'pc':
                # Check if the target machine is the host
                if machine == host:
                    # Don't do anything, otherwise MPI_Abort will kill the instance of Python that launched
                    # the MPI_Abort command
                    unix_command = ''
                else:
                    # The target machine is a remote PC.
                    if OS.isunix:
                        # The host machine is a Unix machine
                        unix_command = remote_launch+machine+remote_flags+' '+q+'taskkill /f /FI "USERNAME eq '+username+'" /im python.exe'+q
                    else:
                        unix_command = remote_launch+machine+remote_flags+' '+qq+'taskkill /f /FI \"USERNAME eq '+username+'\" /im python.exe'+qq

            else:  # pid != 'pc' [target machine is a Unix machines]
                #Check if the target machine is the host
                if machine == host:
                    unix_command = 'kill -9 '+pid
                else:
                    if OS.isunix:
                        # The host machine is a  Unix machine
                        unix_command = remote_launch+machine+remote_flags+' '+q+'kill -9 '+pid+q
                    else:
                        # the host machine is a PC machine
                        unix_command = remote_launch+machine+remote_flags+' '+qq+'kill -9 '+pid+qq
            # Print the command and execute it
            print(unix_command)
            os.system(unix_command)

    # Rename PythonMPI directory before deleting it
    if os.path.exists( os.path.join(os.getcwd(),'PythonMPI') ):
        # Rename PythonMPI to a temporary name
        rand_string = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(5))
        NewPythonMPI = 'PythonMPI_'+rand_string 
        os.rename('PythonMPI',NewPythonMPI)
        # Execute a command and capture the output
        result = subprocess.run(['rm', '-fr', NewPythonMPI, '&'], capture_output=True, text=True)
        
    return

########################################################
# MatlabMPI
# Dr. Jeremy Kepner
# MIT Lincoln Laboratory
# kepner@ll.mit.edu
########################################################
# Copyright 2002 Massachusetts Institute of Technology
#
# Permission is herby granted, without payment, to copy, modify, display
# and distribute this software and its documentation, if any, for any
# purpose, provided that the above copyright notices and the following
# three paragraphs appear in all copies of this software.  Use of this
# software constitutes acceptance of these terms and conditions.
#
# IN NO EVENT SHALL MIT BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT,
# SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OF
# THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF MIT HAS BEEN ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
#
# MIT SPECIFICALLY DISCLAIMS ANY EXPRESS OR IMPLIED WARRANTIES INCLUDING,
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
# FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
#
# THIS SOFTWARE IS PROVIDED "AS IS," MIT HAS NO OBLIGATION TO PROVIDE
# MAINTENANCE, SUPPORT, UPDATE, ENHANCEMENTS, OR MODIFICATIONS.
